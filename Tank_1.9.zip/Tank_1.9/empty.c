/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "Base_Motor.h"
#include "Encoder.h"
#include "Track_Detector.h"
#include "Grayscale_Sensor.h"
#include "Open_MV.h"
#include "Pan_Tilt.h"
#include "Switch.h"
#include "Delay.h"
#include "PID.h"

/*全局变量*/
Base_Struct Base_Data={0};
Encoder_Struct Encoder_Data={0};
No_MCU_Sensor GS_Data={0};
Track_Detector_Struct TD_Data={0};
Aim_Position_Struct Aim_Position_Data={0};
Pan_Tilt_Struct PT_Data={0};
volatile Task_Structure Task_Data={Disable_Aim,Unfinished,0};

/*循迹模式*/
#define Stop_Mode 0x00
#define Following_Mode 0x01
uint8_t Tracking_Mode=Stop_Mode;

/*转角检测状态*/
#define Added 0x01
#define Unadded 0x00
uint8_t Turns_Flag = Unadded;

/*Test*/
#define Testing_Mode 0x01
#define Working_Mode 0x00
uint8_t Mode=Working_Mode;

unsigned short Test[8]={0};
uint8_t Address=0;

int main(void)
{
    SYSCFG_DL_init();

    NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(DL_INTERRUPT_GROUP1_GPIOA);
    NVIC_EnableIRQ(DL_INTERRUPT_GROUP1_GPIOB);
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);

    DL_TimerG_startCounter(Base_Motor_INST);
    DL_TimerG_startCounter(Base_Servo_INST);
    DL_TimerG_startCounter(Pan_Tilt_Servo_INST);

    Grayscale_Sensor_Init(&GS_Data);

    DL_GPIO_clearPins(GPIO_Motor_STBY_PORT, GPIO_Motor_STBY_PIN); //STBY置低，失能TB6612电桥
    DL_GPIO_clearPins(GPIO_Laser_PORT, GPIO_Laser_Laser_Pin_PIN); //关闭激光

    Tracking_Mode = Stop_Mode;


    while(Mode == Working_Mode)
    {
        /*初始化所有配置*/
        Task_Data.Aim_Mode=Disable_Aim;
        Task_Data.Target_Rounds=0;
        Task_Data.Target_Turns=0;
        Task_Data.Actual_Turns=0;

        /*等待“配置完成”指示,配置完成后开始执行任务（按键控制）*/
        while(Task_Data.Config_State == Unfinished);

        Task_Data.Target_Turns = 4*Task_Data.Target_Rounds;
        Task_Data.Actual_Turns = 0; //确保任务开始时实际圈数为0

        //等待瞄准
        if(Task_Data.Aim_Mode == Aim_At_Center || Task_Data.Aim_Mode == Aim_At_Circle)
        {
            while(abs(PT_Data.Target_Theta_Offset-PT_Data.Actual_Theta_Offset) > 3 || abs(PT_Data.Target_Phi_Offset-PT_Data.Actual_Phi_Offset) > 3);
            DL_GPIO_setPins(GPIO_Laser_PORT, GPIO_Laser_Laser_Pin_PIN);
        }

        Tracking_Mode = Following_Mode;

        /*执行任务时的循环*/
        while(Task_Data.Config_State == Finished)
        {
            //检测到离散程度较大时，说明到达转角
            if(TD_Data.Result == Deviating_State && TD_Data.Last_Result == Following_State && Turns_Flag == Unadded)
            {
                Task_Data.Actual_Turns++;
                Turns_Flag = Added;
            }
            //回到直线
            else if(TD_Data.Result == Following_State && TD_Data.Last_Result == Following_State)
            {
                Turns_Flag = Unadded;
            }

            //判断转角数是否足够
            if(Task_Data.Actual_Turns > Task_Data.Target_Turns)
            {
                //结束本次任务，等待下一任务的配置
                Task_Data.Config_State = Unfinished;
                Tracking_Mode = Stop_Mode;
            }

        }
    }



/*==============================================Test==============================================*/
    uint8_t Count=0;
    uint32_t Result[8]={0};

    DL_GPIO_clearPins(GPIO_Motor_STBY_PORT, GPIO_Motor_STBY_PIN);  //STBY置低，失能TB6612电桥
    Tracking_Mode = Stop_Mode;

    Set_Pan_Tilt_Profile(10,15);
    Delay_ms(1000);

    while (Mode == Testing_Mode) 
    {
        
        // Set_Pan_Tilt_Profile(-10,-15);
        // Delay_ms(1000);
    }
}



/*Group1中断服务函数（包含GPIOA、GPIOB）*/
void GROUP1_IRQHandler(void)
{
    /*编码器中断服务函数*/
    Encoder_IRQHandler(&Encoder_Data);

    /*按键中断服务函数*/
    Switch_Handler(&Task_Data,&Tracking_Mode);
}


/*PID_Timer中断服务函数，每50ms进入一次中断*/
void PID_Timer_INST_IRQHandler(void)
{
    /*周期检测部分*/
    Encoder_Detect_Handler(&Base_Data,&Encoder_Data);
    Track_Detector_Detect_Handler(&TD_Data);

    /*依据指令决定底盘执行函数*/
    if(Tracking_Mode == Following_Mode)
    {
        Base_Follow_Track_PID_Handler(&Base_Data,&TD_Data);
    }
    else if(Tracking_Mode == Stop_Mode)
    {
        Base_Data.Target_Linear_Speed = 0;
        Base_Data.Target_Curvature = 0;
        Set_Move_Profile(&Base_Data);
    }

    /*周期PID控制底层控制部分*/
    Base_Motor_PID_Handler(&Base_Data);
    Set_Base_Servo_Angle(Base_Data.Base_Servo_Angle_Deg);
}

/*串口中断服务函数*/
void UART_2_INST_IRQHandler(void)
{
    Open_MV_Receive_Handler(&Aim_Position_Data);

    if(Aim_Position_Data.Receive_State == Received)
    {
        PT_Data.Actual_Theta_Offset = Aim_Position_Data.X;
        PT_Data.Actual_Phi_Offset = Aim_Position_Data.Y;

        /*依据指令决定云台执行函数*/
        if(Task_Data.Aim_Mode == Aim_At_Center)
        {
            //控制目标中心在屏幕的(0,0)
            PT_Data.Target_Theta_Offset = 0;
            PT_Data.Target_Phi_Offset = 0;
            Pan_Tilt_PID_Handler(&PT_Data,&Base_Data);
        }
        else if(Task_Data.Aim_Mode == Aim_At_Circle)
        {

        }

        /*test*/
        printf("%.0f,%.0f,%.0f,%.0f,%.0f,%.0f\r\n",PT_Data.Actual_Theta_Offset,PT_Data.Target_Theta_Offset,PT_Data.Actual_Phi_Offset,
        PT_Data.Target_Phi_Offset,PT_Data.Target_Omega_Theta,PT_Data.Target_Angle_Phi);

        Aim_Position_Data.Receive_State = Unreceived;
    }
}
