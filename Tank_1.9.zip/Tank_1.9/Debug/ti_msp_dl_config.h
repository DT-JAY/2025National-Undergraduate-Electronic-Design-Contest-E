/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000



/* Defines for Pan_Tilt_Servo */
#define Pan_Tilt_Servo_INST                                                TIMA0
#define Pan_Tilt_Servo_INST_IRQHandler                          TIMA0_IRQHandler
#define Pan_Tilt_Servo_INST_INT_IRQN                            (TIMA0_INT_IRQn)
#define Pan_Tilt_Servo_INST_CLK_FREQ                                      500000
/* GPIO defines for channel 0 */
#define GPIO_Pan_Tilt_Servo_C0_PORT                                        GPIOA
#define GPIO_Pan_Tilt_Servo_C0_PIN                                 DL_GPIO_PIN_8
#define GPIO_Pan_Tilt_Servo_C0_IOMUX                             (IOMUX_PINCM19)
#define GPIO_Pan_Tilt_Servo_C0_IOMUX_FUNC             IOMUX_PINCM19_PF_TIMA0_CCP0
#define GPIO_Pan_Tilt_Servo_C0_IDX                           DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_Pan_Tilt_Servo_C1_PORT                                        GPIOB
#define GPIO_Pan_Tilt_Servo_C1_PIN                                 DL_GPIO_PIN_9
#define GPIO_Pan_Tilt_Servo_C1_IOMUX                             (IOMUX_PINCM26)
#define GPIO_Pan_Tilt_Servo_C1_IOMUX_FUNC             IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_Pan_Tilt_Servo_C1_IDX                           DL_TIMER_CC_1_INDEX

/* Defines for Base_Servo */
#define Base_Servo_INST                                                    TIMG6
#define Base_Servo_INST_IRQHandler                              TIMG6_IRQHandler
#define Base_Servo_INST_INT_IRQN                                (TIMG6_INT_IRQn)
#define Base_Servo_INST_CLK_FREQ                                          500000
/* GPIO defines for channel 0 */
#define GPIO_Base_Servo_C0_PORT                                            GPIOB
#define GPIO_Base_Servo_C0_PIN                                     DL_GPIO_PIN_2
#define GPIO_Base_Servo_C0_IOMUX                                 (IOMUX_PINCM15)
#define GPIO_Base_Servo_C0_IOMUX_FUNC                IOMUX_PINCM15_PF_TIMG6_CCP0
#define GPIO_Base_Servo_C0_IDX                               DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_Base_Servo_C1_PORT                                            GPIOA
#define GPIO_Base_Servo_C1_PIN                                     DL_GPIO_PIN_6
#define GPIO_Base_Servo_C1_IOMUX                                 (IOMUX_PINCM11)
#define GPIO_Base_Servo_C1_IOMUX_FUNC                IOMUX_PINCM11_PF_TIMG6_CCP1
#define GPIO_Base_Servo_C1_IDX                               DL_TIMER_CC_1_INDEX

/* Defines for Base_Motor */
#define Base_Motor_INST                                                    TIMG7
#define Base_Motor_INST_IRQHandler                              TIMG7_IRQHandler
#define Base_Motor_INST_INT_IRQN                                (TIMG7_INT_IRQn)
#define Base_Motor_INST_CLK_FREQ                                        10000000
/* GPIO defines for channel 0 */
#define GPIO_Base_Motor_C0_PORT                                            GPIOA
#define GPIO_Base_Motor_C0_PIN                                    DL_GPIO_PIN_17
#define GPIO_Base_Motor_C0_IOMUX                                 (IOMUX_PINCM39)
#define GPIO_Base_Motor_C0_IOMUX_FUNC                IOMUX_PINCM39_PF_TIMG7_CCP0
#define GPIO_Base_Motor_C0_IDX                               DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_Base_Motor_C1_PORT                                            GPIOA
#define GPIO_Base_Motor_C1_PIN                                    DL_GPIO_PIN_18
#define GPIO_Base_Motor_C1_IOMUX                                 (IOMUX_PINCM40)
#define GPIO_Base_Motor_C1_IOMUX_FUNC                IOMUX_PINCM40_PF_TIMG7_CCP1
#define GPIO_Base_Motor_C1_IDX                               DL_TIMER_CC_1_INDEX



/* Defines for PID_Timer */
#define PID_Timer_INST                                                   (TIMG8)
#define PID_Timer_INST_IRQHandler                               TIMG8_IRQHandler
#define PID_Timer_INST_INT_IRQN                                 (TIMG8_INT_IRQn)
#define PID_Timer_INST_LOAD_VALUE                                         (999U)



/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                           40000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_11
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_10
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM22)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM21)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM21_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_0_FBRD_40_MHZ_115200_BAUD                                      (45)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                           40000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOB
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_16
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_15
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM33)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM32)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM33_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM32_PF_UART2_TX
#define UART_2_BAUD_RATE                                                (115200)
#define UART_2_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_2_FBRD_40_MHZ_115200_BAUD                                      (45)





/* Defines for ADC12_0 */
#define ADC12_0_INST                                                        ADC0
#define ADC12_0_INST_IRQHandler                                  ADC0_IRQHandler
#define ADC12_0_INST_INT_IRQN                                    (ADC0_INT_IRQn)
#define ADC12_0_ADCMEM_0                                      DL_ADC12_MEM_IDX_0
#define ADC12_0_ADCMEM_0_REF                     DL_ADC12_REFERENCE_VOLTAGE_VDDA
#define ADC12_0_ADCMEM_0_REF_VOLTAGE_V                                       3.3
#define GPIO_ADC12_0_C0_PORT                                               GPIOA
#define GPIO_ADC12_0_C0_PIN                                       DL_GPIO_PIN_27



/* Port definition for Pin Group GPIO_LED */
#define GPIO_LED_PORT                                                    (GPIOB)

/* Defines for LED_1: GPIOB.14 with pinCMx 31 on package pin 2 */
#define GPIO_LED_LED_1_PIN                                      (DL_GPIO_PIN_14)
#define GPIO_LED_LED_1_IOMUX                                     (IOMUX_PINCM31)
/* Port definition for Pin Group GPIO_Laser */
#define GPIO_Laser_PORT                                                  (GPIOB)

/* Defines for Laser_Pin: GPIOB.0 with pinCMx 12 on package pin 47 */
#define GPIO_Laser_Laser_Pin_PIN                                 (DL_GPIO_PIN_0)
#define GPIO_Laser_Laser_Pin_IOMUX                               (IOMUX_PINCM12)
/* Port definition for Pin Group GPIO_Encoder */
#define GPIO_Encoder_PORT                                                (GPIOB)

/* Defines for Encoder1A: GPIOB.5 with pinCMx 18 on package pin 53 */
// groups represented: ["GPIO_Switch","GPIO_Encoder"]
// pins affected: ["Swicth1","Swicth2","Encoder1A","Encoder1B","Encoder2A","Encoder2B"]
#define GPIO_MULTIPLE_GPIOB_INT_IRQN                            (GPIOB_INT_IRQn)
#define GPIO_MULTIPLE_GPIOB_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_Encoder_Encoder1A_IIDX                          (DL_GPIO_IIDX_DIO5)
#define GPIO_Encoder_Encoder1A_PIN                               (DL_GPIO_PIN_5)
#define GPIO_Encoder_Encoder1A_IOMUX                             (IOMUX_PINCM18)
/* Defines for Encoder1B: GPIOB.6 with pinCMx 23 on package pin 58 */
#define GPIO_Encoder_Encoder1B_IIDX                          (DL_GPIO_IIDX_DIO6)
#define GPIO_Encoder_Encoder1B_PIN                               (DL_GPIO_PIN_6)
#define GPIO_Encoder_Encoder1B_IOMUX                             (IOMUX_PINCM23)
/* Defines for Encoder2A: GPIOB.7 with pinCMx 24 on package pin 59 */
#define GPIO_Encoder_Encoder2A_IIDX                          (DL_GPIO_IIDX_DIO7)
#define GPIO_Encoder_Encoder2A_PIN                               (DL_GPIO_PIN_7)
#define GPIO_Encoder_Encoder2A_IOMUX                             (IOMUX_PINCM24)
/* Defines for Encoder2B: GPIOB.8 with pinCMx 25 on package pin 60 */
#define GPIO_Encoder_Encoder2B_IIDX                          (DL_GPIO_IIDX_DIO8)
#define GPIO_Encoder_Encoder2B_PIN                               (DL_GPIO_PIN_8)
#define GPIO_Encoder_Encoder2B_IOMUX                             (IOMUX_PINCM25)
/* Defines for BIN2: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_Motor_BIN2_PORT                                             (GPIOB)
#define GPIO_Motor_BIN2_PIN                                     (DL_GPIO_PIN_19)
#define GPIO_Motor_BIN2_IOMUX                                    (IOMUX_PINCM45)
/* Defines for BIN1: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_Motor_BIN1_PORT                                             (GPIOA)
#define GPIO_Motor_BIN1_PIN                                     (DL_GPIO_PIN_22)
#define GPIO_Motor_BIN1_IOMUX                                    (IOMUX_PINCM47)
/* Defines for STBY: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_Motor_STBY_PORT                                             (GPIOB)
#define GPIO_Motor_STBY_PIN                                     (DL_GPIO_PIN_18)
#define GPIO_Motor_STBY_IOMUX                                    (IOMUX_PINCM44)
/* Defines for AIN1: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GPIO_Motor_AIN1_PORT                                             (GPIOA)
#define GPIO_Motor_AIN1_PIN                                     (DL_GPIO_PIN_24)
#define GPIO_Motor_AIN1_IOMUX                                    (IOMUX_PINCM54)
/* Defines for AIN2: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GPIO_Motor_AIN2_PORT                                             (GPIOA)
#define GPIO_Motor_AIN2_PIN                                     (DL_GPIO_PIN_15)
#define GPIO_Motor_AIN2_IOMUX                                    (IOMUX_PINCM37)
/* Defines for Swicth1: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_Switch_Swicth1_PORT                                         (GPIOB)
#define GPIO_Switch_Swicth1_IIDX                            (DL_GPIO_IIDX_DIO22)
#define GPIO_Switch_Swicth1_PIN                                 (DL_GPIO_PIN_22)
#define GPIO_Switch_Swicth1_IOMUX                                (IOMUX_PINCM50)
/* Defines for Swicth2: GPIOB.23 with pinCMx 51 on package pin 22 */
#define GPIO_Switch_Swicth2_PORT                                         (GPIOB)
#define GPIO_Switch_Swicth2_IIDX                            (DL_GPIO_IIDX_DIO23)
#define GPIO_Switch_Swicth2_PIN                                 (DL_GPIO_PIN_23)
#define GPIO_Switch_Swicth2_IOMUX                                (IOMUX_PINCM51)
/* Defines for Swicth3: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_Switch_Swicth3_PORT                                         (GPIOA)
// pins affected by this interrupt request:["Swicth3","Swicth4","Swicth5","Swicth6"]
#define GPIO_Switch_GPIOA_INT_IRQN                              (GPIOA_INT_IRQn)
#define GPIO_Switch_GPIOA_INT_IIDX              (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_Switch_Swicth3_IIDX                            (DL_GPIO_IIDX_DIO13)
#define GPIO_Switch_Swicth3_PIN                                 (DL_GPIO_PIN_13)
#define GPIO_Switch_Swicth3_IOMUX                                (IOMUX_PINCM35)
/* Defines for Swicth4: GPIOA.3 with pinCMx 8 on package pin 43 */
#define GPIO_Switch_Swicth4_PORT                                         (GPIOA)
#define GPIO_Switch_Swicth4_IIDX                             (DL_GPIO_IIDX_DIO3)
#define GPIO_Switch_Swicth4_PIN                                  (DL_GPIO_PIN_3)
#define GPIO_Switch_Swicth4_IOMUX                                 (IOMUX_PINCM8)
/* Defines for Swicth5: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_Switch_Swicth5_PORT                                         (GPIOA)
#define GPIO_Switch_Swicth5_IIDX                             (DL_GPIO_IIDX_DIO7)
#define GPIO_Switch_Swicth5_PIN                                  (DL_GPIO_PIN_7)
#define GPIO_Switch_Swicth5_IOMUX                                (IOMUX_PINCM14)
/* Defines for Swicth6: GPIOA.23 with pinCMx 53 on package pin 24 */
#define GPIO_Switch_Swicth6_PORT                                         (GPIOA)
#define GPIO_Switch_Swicth6_IIDX                            (DL_GPIO_IIDX_DIO23)
#define GPIO_Switch_Swicth6_PIN                                 (DL_GPIO_PIN_23)
#define GPIO_Switch_Swicth6_IOMUX                                (IOMUX_PINCM53)
/* Defines for Detector_1: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_Track_Detector_Detector_1_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_1_PIN                      (DL_GPIO_PIN_13)
#define GPIO_Track_Detector_Detector_1_IOMUX                     (IOMUX_PINCM30)
/* Defines for Detector_2: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_Track_Detector_Detector_2_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_2_PIN                      (DL_GPIO_PIN_20)
#define GPIO_Track_Detector_Detector_2_IOMUX                     (IOMUX_PINCM48)
/* Defines for Detector_3: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_Track_Detector_Detector_3_PORT                              (GPIOA)
#define GPIO_Track_Detector_Detector_3_PIN                      (DL_GPIO_PIN_31)
#define GPIO_Track_Detector_Detector_3_IOMUX                      (IOMUX_PINCM6)
/* Defines for Detector_4: GPIOA.28 with pinCMx 3 on package pin 35 */
#define GPIO_Track_Detector_Detector_4_PORT                              (GPIOA)
#define GPIO_Track_Detector_Detector_4_PIN                      (DL_GPIO_PIN_28)
#define GPIO_Track_Detector_Detector_4_IOMUX                      (IOMUX_PINCM3)
/* Defines for Detector_5: GPIOB.1 with pinCMx 13 on package pin 48 */
#define GPIO_Track_Detector_Detector_5_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_5_PIN                       (DL_GPIO_PIN_1)
#define GPIO_Track_Detector_Detector_5_IOMUX                     (IOMUX_PINCM13)
/* Defines for Detector_6: GPIOB.4 with pinCMx 17 on package pin 52 */
#define GPIO_Track_Detector_Detector_6_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_6_PIN                       (DL_GPIO_PIN_4)
#define GPIO_Track_Detector_Detector_6_IOMUX                     (IOMUX_PINCM17)
/* Defines for Detector_7: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_Track_Detector_Detector_7_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_7_PIN                      (DL_GPIO_PIN_17)
#define GPIO_Track_Detector_Detector_7_IOMUX                     (IOMUX_PINCM43)
/* Defines for Detector_8: GPIOB.12 with pinCMx 29 on package pin 64 */
#define GPIO_Track_Detector_Detector_8_PORT                              (GPIOB)
#define GPIO_Track_Detector_Detector_8_PIN                      (DL_GPIO_PIN_12)
#define GPIO_Track_Detector_Detector_8_IOMUX                     (IOMUX_PINCM29)
/* Defines for PIN_0: GPIOB.24 with pinCMx 52 on package pin 23 */
#define Gray_Address_PIN_0_PORT                                          (GPIOB)
#define Gray_Address_PIN_0_PIN                                  (DL_GPIO_PIN_24)
#define Gray_Address_PIN_0_IOMUX                                 (IOMUX_PINCM52)
/* Defines for PIN_1: GPIOA.25 with pinCMx 55 on package pin 26 */
#define Gray_Address_PIN_1_PORT                                          (GPIOA)
#define Gray_Address_PIN_1_PIN                                  (DL_GPIO_PIN_25)
#define Gray_Address_PIN_1_IOMUX                                 (IOMUX_PINCM55)
/* Defines for PIN_2: GPIOB.3 with pinCMx 16 on package pin 51 */
#define Gray_Address_PIN_2_PORT                                          (GPIOB)
#define Gray_Address_PIN_2_PIN                                   (DL_GPIO_PIN_3)
#define Gray_Address_PIN_2_IOMUX                                 (IOMUX_PINCM16)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_Pan_Tilt_Servo_init(void);
void SYSCFG_DL_Base_Servo_init(void);
void SYSCFG_DL_Base_Motor_init(void);
void SYSCFG_DL_PID_Timer_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_ADC12_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
