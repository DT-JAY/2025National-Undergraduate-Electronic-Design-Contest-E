#include "ti_msp_dl_config.h"
#include "string.h"
#include "stdio.h"
#include "Open_MV.h"

#include "Usart_0.h"


Aim_Position_Struct Aim_Position;

// 接收标志

// 解析后的数据
static uint8_t parsed_get, parsed_x, parsed_y;
static uint8_t cnt = 0;

// 数据总长度（宏定义控制）
volatile uint8_t gRxPacket_0[UART_PACKET_SIZE];
uint8_t gTxPacket_0[UART_PACKET_SIZE];

uint8_t gTxPacket_1[UART_PACKET_SIZE];
volatile uint8_t gReceiveData = 0;

// 错误标识字节（用于区分不同错误，可自定义）
#define ERROR_HEADER    0xE1  // 包头错误标识
#define ERROR_PREAMBLE  0xE2  // 前导错误标识
#define ERROR_TAIL      0xE3  // 包尾错误标识
#define ERROR_UNEXPECT  0xE4  // 意外状态错误标识
#define ERROR_DEFAULT   0xE5  // 默认错误标识


/************************* UART0 RX中断处理 *************************/

void Open_MV_Receive_Handler(Aim_Position_Struct* pAim_Position_Data)
{
    switch (DL_UART_Main_getPendingInterrupt(UART_2_INST)) {
        case DL_UART_MAIN_IIDX_RX:

            gReceiveData = DL_UART_Main_receiveData(UART_2_INST);

            
            
            if (cnt == 0) {  // 阶段0：等待包头0xA3
                if (gReceiveData == 0xA3) {
                    gRxPacket_0[0] = gReceiveData;
                    // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                    cnt = 1;
                } else {
                    // 发送错误标识（原始字节）
                    // DL_UART_Main_transmitData(UART_2_INST, ERROR_HEADER);
                    cnt = 0;
                }
            } 
            else if (cnt == 1) {  // 阶段1：等待前导0xB3
                if (gReceiveData == 0xB3) {
                    gRxPacket_0[1] = gReceiveData;
                    // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                    cnt = 2;
                } else {
                    // 发送错误标识（原始字节）
                    // DL_UART_Main_transmitData(UART_2_INST, ERROR_PREAMBLE);
                    cnt = 0;
                }
            } 
            else if (cnt == 2) {  // 阶段2：接收payload[0]
                gRxPacket_0[2] = gReceiveData;
                // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                cnt = 3;
            } 
            else if (cnt == 3) {  // 阶段3：接收payload[1]
                gRxPacket_0[3] = gReceiveData;
                // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                cnt = 4;
            } 
            else if (cnt == 4) {  // 阶段4：接收payload[2]
                gRxPacket_0[4] = gReceiveData;
                // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                cnt = 5;
            } 
            else if (cnt == 5) {  // 阶段4：接收payload[2]
                gRxPacket_0[5] = gReceiveData;
                // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                cnt = 6;
            } 
            else if (cnt == 6) {  // 阶段5：等待包尾0xC3
                if (gReceiveData == 0xC3) {
                    gRxPacket_0[6] = gReceiveData;
                    // DL_UART_Main_transmitData(UART_2_INST, gRxPacket_0[cnt]);  // 回发原始字节
                    cnt = 0;

                    // printf("%d,%d,%d,%d,%d\r\n",gRxPacket_0[0],gRxPacket_0[1],gRxPacket_0[2],gRxPacket_0[3],gRxPacket_0[4]);

                    // pAim_Position_Data->X = gRxPacket_0[4];
                    // pAim_Position_Data->Y = -gRxPacket_0[5];

                    pAim_Position_Data->Receive_State = Received;

                    pAim_Position_Data->X = gRxPacket_0[2]-gRxPacket_0[4];
                    pAim_Position_Data->Y = gRxPacket_0[5]-gRxPacket_0[3];

                    // Aim_Position.X=gRxPacket_0[2]-gRxPacket_0[4];
                    // Aim_Position.Y=gRxPacket_0[5]-gRxPacket_0[3];

                    // DL_UART_Main_transmitDataBlocking(UART_2_INST, Aim_Position.Y);
                    // DL_UART_Main_transmitDataBlocking(UART_2_INST, Aim_Position.X); 
                     
                } else {
                    // 发送错误标识（原始字节）
                    // DL_UART_Main_transmitData(UART_2_INST, ERROR_TAIL);
                    cnt = 0;
                }
            } 
            else {  // 意外状态处理
                // 发送错误标识（原始字节）
                // DL_UART_Main_transmitData(UART_2_INST, ERROR_UNEXPECT);
                cnt = 0;
            }
            break;
            
        default:
            // 发送默认错误标识（原始字节）
            // DL_UART_Main_transmitData(UART_2_INST, ERROR_DEFAULT);
    }
}

/*读取位置数据*/
void Open_MV_Data_Transmit(Aim_Position_Struct* pAim_Position_Data)
{
    pAim_Position_Data->X = Aim_Position.X;
    pAim_Position_Data->Y = Aim_Position.Y;
}

/************************* UART1 TX DMA中断（预留） *************************/
// void UART_1_INST_IRQHandler(void)
// {
//     switch (DL_UART_Main_getPendingInterrupt(UART_1_INST)) {
//         case DL_UART_MAIN_IIDX_EOT_DONE:
//             gCheckUART_uart1_TX = true;
//             break;
//         case DL_UART_MAIN_IIDX_DMA_DONE_TX:
//             gDMADone_uart1 = true;
//             break;
//         default:
//             break;
//     }
// }

/************************* 主函数 *************************/
// int main(void) {
//     SYSCFG_DL_init();  // 初始化所有外设

//    

//     while (1) {

//     }
// }
