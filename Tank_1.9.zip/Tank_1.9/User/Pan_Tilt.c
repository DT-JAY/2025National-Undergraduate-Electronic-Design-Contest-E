#include "ti_msp_dl_config.h"
#include "Pan_Tilt.h"

void Set_Pan_Tilt_Profile(float Omega_Theta_Deg,float Angle_Phi_Deg)
{
    uint16_t CompareValue;

    if(Angle_Phi_Deg > 90) Angle_Phi_Deg = 90;
    else if(Angle_Phi_Deg < -90) Angle_Phi_Deg = -90;
    CompareValue = (1000*Angle_Phi_Deg)/180+750;
    DL_TimerG_setCaptureCompareValue(Pan_Tilt_Servo_INST,CompareValue,GPIO_Pan_Tilt_Servo_C0_IDX);

    if(Omega_Theta_Deg > 90) Omega_Theta_Deg = 90;
    else if(Omega_Theta_Deg < -90) Omega_Theta_Deg = -90;
    CompareValue = (1000*Omega_Theta_Deg)/180+750;
    DL_TimerG_setCaptureCompareValue(Pan_Tilt_Servo_INST,CompareValue,GPIO_Pan_Tilt_Servo_C1_IDX);
}
