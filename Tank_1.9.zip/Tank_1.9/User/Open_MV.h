#ifndef __OPEN_MV_H__
#define __OPEN_MV_H__

#define UART_PACKET_SIZE (16)

#define Received 0x01
#define Unreceived 0x00

typedef struct{
    //坐标为目标物体相对于摄像头中心（令摄像头中心为原点，上方为Y轴正方向，右方为X轴正方向）的坐标
    uint8_t Receive_State;
    int8_t X;
    int8_t Y;
}Aim_Position_Struct;

void Open_MV_Receive_Handler(Aim_Position_Struct* pAim_Position_Data);
void Open_MV_Data_Transmit(Aim_Position_Struct* pAim_Position_Data);

#endif
