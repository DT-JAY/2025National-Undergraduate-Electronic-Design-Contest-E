#ifndef __PID_H__
#define __PID_H__

#include "Pan_Tilt.h"
#include "Base_Motor.h"
#include "Base_Move.h"
#include "Track_Detector.h"

typedef struct{
    float Kp;
    float Ki;
    float Kd;
    float Int_Limit;
    float Dead_Zone;
}PID_Param_Struct;

typedef struct{
    float Target;
    float Actual;
    float Error_Int;
    float Last_Error;
    float Last_Output;
}PID_Input_Struct;

void Pan_Tilt_PID_Handler(Pan_Tilt_Struct* pPT_Data,Base_Struct* pBase_Data);
void Base_Motor_PID_Handler(Base_Struct* pBase_Data);
void Set_Base_Motor_PID_Error_Int(float Reference);
void Base_Follow_Track_PID_Handler(Base_Struct* pBase_Data,Track_Detector_Struct* pTD_Data);

float PID_Calculate(PID_Input_Struct* pInput,PID_Param_Struct* pParam);

#endif
