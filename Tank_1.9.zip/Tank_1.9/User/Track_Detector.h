#ifndef __TRACK_DETECTOR_H__
#define __TRACK_DETECTOR_H__

#include "Grayscale_Sensor.h"

#define No_Track 0x00
#define Found_Track 0x01

#define Following_State 'F'
#define Deviating_State 'D'
#define Missing_State 'M'

typedef struct{
    uint8_t Raw;
    uint8_t Result;
    uint8_t Last_Result;
    float Offset;
    float Dispersion;
}volatile Track_Detector_Struct;

void Track_Detector_Detect_Handler(Track_Detector_Struct* pTD_Data);
void Get_Track_Detector_Data(Track_Detector_Struct* pTD_Data,int8_t* TD_Data_Array);
float Get_TD_Dispersion_Data(int8_t* TD_Data_Array , float TD_Offet);
float Get_TD_Offet_Data(int8_t* TD_Data_Array);
void TD_Data_Process(int8_t* TD_Data_Array,uint8_t TD_Data_Raw);
uint8_t Read_Track_Detector_Raw(void);

#endif
