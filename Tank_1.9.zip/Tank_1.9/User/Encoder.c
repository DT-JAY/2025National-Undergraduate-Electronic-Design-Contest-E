#include "ti_msp_dl_config.h"
#include "Encoder.h"
#include "Usart_0.h"

/*编码器测速服务函数*/
void Encoder_Detect_Handler(Base_Struct* pBase_Data,Encoder_Struct* pEncoder_Data)
{
    //获取两轮实际速度
    Get_Wheel_Distance(pEncoder_Data);
    pBase_Data->Actual_Speed_Left = -pEncoder_Data->Distance_Left*0.001/0.050;
    pBase_Data->Actual_Speed_Right = pEncoder_Data->Distance_Right*0.001/0.050;

    //计算线速度、以及曲率
    pBase_Data->Actual_Linear_Speed = (pBase_Data->Actual_Speed_Left + pBase_Data->Actual_Speed_Right)/2.0;

    if(pBase_Data->Actual_Linear_Speed != 0)
    {
        pBase_Data->Actual_Curvature = 2*(pBase_Data->Actual_Speed_Left - pBase_Data->Actual_Speed_Right)
        /(L1*pBase_Data->Actual_Linear_Speed);
    }
    else
    {
        pBase_Data->Actual_Curvature = 0;
    }
}

/*获取自上一次调用此函数至今期间两轮行驶的距离，并将编码器缓存值清零*/
void Get_Wheel_Distance(Encoder_Struct* pEncoder_Data)
{
    /*中值滤波：取最近三次数据的中间值*/
    Encoder_Raw_Transfer(pEncoder_Data);//转运最近3次Encoder数据
    Encoder_Raw_Transfer_Middle_Value(pEncoder_Data);//转运最近3次数据的中间值

    /*将数据处理为轮子速度(m/s)，并转运*/
    pEncoder_Data->Distance_Left = (float)((float)pEncoder_Data->Encoder1_Count/2/Line_Count/Reduct_Ratio*2*Pi*Wheel_Radius);
    pEncoder_Data->Distance_Right = (float)((float)pEncoder_Data->Encoder2_Count/2/Line_Count/Reduct_Ratio*2*Pi*Wheel_Radius);

    /*清除Encoder缓存数据*/
    pEncoder_Data->Encoder1_Count=0;
    pEncoder_Data->Encoder2_Count=0;
}

/*转运Encoder数据*/
void Encoder_Raw_Transfer(Encoder_Struct* pEncoder_Data)
{
    //更迭最新的三个数据
    pEncoder_Data->Encoder1_Raw[2] = pEncoder_Data->Encoder1_Raw[1];
    pEncoder_Data->Encoder1_Raw[1] = pEncoder_Data->Encoder1_Raw[0];
    pEncoder_Data->Encoder1_Raw[0] = pEncoder_Data->Encoder1_Count;

    pEncoder_Data->Encoder2_Raw[2] = pEncoder_Data->Encoder2_Raw[1];
    pEncoder_Data->Encoder2_Raw[1] = pEncoder_Data->Encoder2_Raw[0];
    pEncoder_Data->Encoder2_Raw[0] = pEncoder_Data->Encoder2_Count;
}

/*对Encoder_Raw[]数据排序并取中间值*/
void Encoder_Raw_Transfer_Middle_Value(Encoder_Struct* pEncoder_Data)
{
    //Encoder_Raw[0]为中间值
    if( ((pEncoder_Data->Encoder1_Raw[0] <= pEncoder_Data->Encoder1_Raw[1]) && (pEncoder_Data->Encoder1_Raw[0] >= pEncoder_Data->Encoder1_Raw[2])) ||
    ((pEncoder_Data->Encoder1_Raw[0] >= pEncoder_Data->Encoder1_Raw[1]) && (pEncoder_Data->Encoder1_Raw[0] <= pEncoder_Data->Encoder1_Raw[2])) )
    {
        pEncoder_Data->Encoder1_Count = pEncoder_Data->Encoder1_Raw[0];
    }

    //Encoder_Raw[1]为中间值
    else if( ((pEncoder_Data->Encoder1_Raw[1] <= pEncoder_Data->Encoder1_Raw[0]) && (pEncoder_Data->Encoder1_Raw[1] >= pEncoder_Data->Encoder1_Raw[2])) ||
    ((pEncoder_Data->Encoder1_Raw[1] >= pEncoder_Data->Encoder1_Raw[0]) && (pEncoder_Data->Encoder1_Raw[1] <= pEncoder_Data->Encoder1_Raw[2])) )
    {
        pEncoder_Data->Encoder1_Count = pEncoder_Data->Encoder1_Raw[1];
    }

    //Encoder_Raw[2]为中间值
    else if( ((pEncoder_Data->Encoder1_Raw[2] <= pEncoder_Data->Encoder1_Raw[0]) && (pEncoder_Data->Encoder1_Raw[2] >= pEncoder_Data->Encoder1_Raw[1])) ||
    ((pEncoder_Data->Encoder1_Raw[2] >= pEncoder_Data->Encoder1_Raw[0]) && (pEncoder_Data->Encoder1_Raw[2] <= pEncoder_Data->Encoder1_Raw[1])) )
    {
        pEncoder_Data->Encoder1_Count = pEncoder_Data->Encoder1_Raw[2];
    }
}

/*编码器运行过程中的中断服务函数，将编码器数据记录在Encoder_Data结构体中*/
void Encoder_IRQHandler(Encoder_Struct* pEncoder_Data)
{
    //获取中断源（GPIO）
    uint32_t Encoder_IT_Source = DL_GPIO_getEnabledInterruptStatus(GPIO_Encoder_PORT,
    GPIO_Encoder_Encoder1A_PIN | GPIO_Encoder_Encoder1B_PIN | GPIO_Encoder_Encoder2A_PIN | GPIO_Encoder_Encoder2B_PIN);

    if(Encoder_IT_Source != 0x0000)
    {
        /*Encoder1 A相触发边沿中断*/
        if((Encoder_IT_Source & GPIO_Encoder_Encoder1A_PIN) == GPIO_Encoder_Encoder1A_PIN)
        {
            if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1A_PIN))  //上升沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1B_PIN)) pEncoder_Data->Encoder1_Count--;
                else pEncoder_Data->Encoder1_Count++;
            }
            else    //下降沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1B_PIN)) pEncoder_Data->Encoder1_Count++;
                else pEncoder_Data->Encoder1_Count--;
            }
        }

        /*Encoder1 B相触发边沿中断*/
        else if((Encoder_IT_Source & GPIO_Encoder_Encoder1B_PIN) == GPIO_Encoder_Encoder1B_PIN)
        {
            if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1B_PIN))  //上升沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1A_PIN)) pEncoder_Data->Encoder1_Count++;
                else pEncoder_Data->Encoder1_Count--;
            }
            else    //下降沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder1A_PIN)) pEncoder_Data->Encoder1_Count--;
                else pEncoder_Data->Encoder1_Count++;
            }
        }

        /*Encoder2 A相触发边沿中断*/
        if((Encoder_IT_Source & GPIO_Encoder_Encoder2A_PIN) == GPIO_Encoder_Encoder2A_PIN)
        {
            if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2A_PIN))  //上升沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2B_PIN)) pEncoder_Data->Encoder2_Count--;
                else pEncoder_Data->Encoder2_Count++;
            }
            else    //下降沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2B_PIN)) pEncoder_Data->Encoder2_Count++;
                else pEncoder_Data->Encoder2_Count--;
            }
        }

        /*Encoder2 B相触发边沿中断*/
        else if((Encoder_IT_Source & GPIO_Encoder_Encoder2B_PIN) == GPIO_Encoder_Encoder2B_PIN)
        {
            if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2B_PIN))  //上升沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2A_PIN)) pEncoder_Data->Encoder2_Count++;
                else pEncoder_Data->Encoder2_Count--;
            }
            else    //下降沿
            {
                if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_Encoder2A_PIN)) pEncoder_Data->Encoder2_Count--;
                else pEncoder_Data->Encoder2_Count++;
            }
        }

        /*清除Encoder标志位*/
        DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT,
        GPIO_Encoder_Encoder1A_PIN | GPIO_Encoder_Encoder1B_PIN | GPIO_Encoder_Encoder2A_PIN | GPIO_Encoder_Encoder2B_PIN);
    }
}
