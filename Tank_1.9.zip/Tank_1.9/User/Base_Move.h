#ifndef __BASE_MOVE_H__
#define __BASE_MOVE_H__

#define L1 113*0.001    //后轮间距(m)
#define L2 62*0.001     //前轮羊角轴间距(m)
#define L3 145*0.001    //前后轴距(m)

#define Max_Curvature 6

#define Pi 3.14159265359

typedef struct{

    /*底盘电机变量*/
    float Actual_Speed_Left;
    float Actual_Speed_Right;
    float Target_Speed_Left;
    float Target_Speed_Right;
    float Target_Power_Left;
    float Target_Power_Right;

    /*底盘舵机变量*/
    float Base_Servo_Angle_Deg;
    
    /*小车运动变量*/
    float Actual_Linear_Speed;
    float Actual_Curvature;
    float Actual_Offet;
    float Target_Linear_Speed;
    float Target_Curvature;

}Base_Struct;

void Base_Culculate_Speed_At_Curvature(Base_Struct* pBase_Data);
void Set_Move_Profile(Base_Struct* pBase_Data);
void Set_Base_Servo_Angle(float Angle_Deg);
float abs_float(float Source);
float Turn_Deg(double Rad);
float Turn_Rad(double Deg);

#endif