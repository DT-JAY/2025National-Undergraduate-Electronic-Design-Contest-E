#include "ti_msp_dl_config.h"
#include "Switch.h"

#define Stop_Mode 0x00
#define Following_Mode 0x01

void Switch_Handler(Task_Structure* pTask_Data,uint8_t* Tracking_Mode)
{
    //获取中断源（GPIO）
    uint32_t Switch_IT_Source_GPIOB = DL_GPIO_getEnabledInterruptStatus(GPIOB,
    GPIO_Switch_Swicth1_PIN | GPIO_Switch_Swicth2_PIN);

    if(Switch_IT_Source_GPIOB != 0x0000)
    {
        /*Switch1触发下降沿中断
          设置瞄准模式：瞄准中心/画圆*/
        if((Switch_IT_Source_GPIOB & GPIO_Switch_Swicth1_PIN) == GPIO_Switch_Swicth1_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth1_PORT,GPIO_Switch_Swicth1_PIN) == 0x0000)
            {
                if(pTask_Data->Aim_Mode == Disable_Aim) //如果原先为失能瞄准模式，则切换为瞄准中心
                {
                    pTask_Data->Aim_Mode = Aim_At_Center;
                }
                else if(pTask_Data->Aim_Mode == Aim_At_Center) //如果原先为瞄准中心，则切换为画圆模式
                {
                    pTask_Data->Aim_Mode = Aim_At_Circle;
                }
                else //其他情况
                {
                    pTask_Data->Aim_Mode = Disable_Aim;
                }
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOB,GPIO_Switch_Swicth1_PIN);
        }

        /*Switch2触发下降沿中断
          设置圈数，按下增加一圈*/
        else if((Switch_IT_Source_GPIOB & GPIO_Switch_Swicth2_PIN) == GPIO_Switch_Swicth2_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth2_PORT,GPIO_Switch_Swicth2_PIN) == 0x0000)
            {
                //圈数增加
                if(pTask_Data->Target_Rounds < 5)
                {
                    pTask_Data->Target_Rounds++;
                }
                else //圈数大于5时回到0
                {
                    pTask_Data->Target_Rounds=0;
                }

                //计数反馈
                if(pTask_Data->Target_Rounds % 2 == 0)
                {
                    //如果为偶数则点亮LED
                    DL_GPIO_setPins(GPIO_LED_PORT,GPIO_LED_LED_1_PIN);
                }
                else
                {
                    //如果为奇数则熄灭LED
                    DL_GPIO_clearPins(GPIO_LED_PORT,GPIO_LED_LED_1_PIN);
                }
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOB,GPIO_Switch_Swicth2_PIN);
        }
    }

    //获取中断源（GPIO）
    uint32_t Switch_IT_Source_GPIOA = DL_GPIO_getEnabledInterruptStatus(GPIOA,
    GPIO_Switch_Swicth3_PIN | GPIO_Switch_Swicth4_PIN | GPIO_Switch_Swicth5_PIN | GPIO_Switch_Swicth6_PIN);

    if(Switch_IT_Source_GPIOA != 0x0000)
    {
        /*Switch3触发下降沿中断
          电机（电桥）开关*/
        if((Switch_IT_Source_GPIOA & GPIO_Switch_Swicth3_PIN) == GPIO_Switch_Swicth3_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth3_PORT,GPIO_Switch_Swicth3_PIN) == 0x0000)
            {
                //清零积分项
                Set_Base_Motor_PID_Error_Int(0);
                //反转STBY电平，及反转电机（电桥）是否通电
                DL_GPIO_togglePins(GPIO_Motor_STBY_PORT, GPIO_Motor_STBY_PIN);
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Switch_Swicth3_PIN);
        }

        /*Switch4触发下降沿中断*/
        else if((Switch_IT_Source_GPIOA & GPIO_Switch_Swicth4_PIN) == GPIO_Switch_Swicth4_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth4_PORT,GPIO_Switch_Swicth4_PIN) == 0x0000)
            {
                
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Switch_Swicth4_PIN);
        }

        /*Switch5触发下降沿中断
          按下完成设置，开始执行任务*/
        else if((Switch_IT_Source_GPIOA & GPIO_Switch_Swicth5_PIN) == GPIO_Switch_Swicth5_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth5_PORT,GPIO_Switch_Swicth5_PIN) == 0x0000)
            {
                if(pTask_Data->Config_State == Unfinished)
                {
                    pTask_Data->Config_State = Finished;
                }
                else
                {
                    pTask_Data->Config_State = Unfinished;
                }
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Switch_Swicth5_PIN);
        }

        /*Switch6触发下降沿中断*/
        else if((Switch_IT_Source_GPIOA & GPIO_Switch_Swicth6_PIN) == GPIO_Switch_Swicth6_PIN)
        {
            //防止运行过程中的电平波动
            Delay_ms(5);
            if(DL_GPIO_readPins(GPIO_Switch_Swicth6_PORT,GPIO_Switch_Swicth6_PIN) == 0x0000)
            {
                
            }
            /*清除Switch标志位*/
            DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Switch_Swicth6_PIN);
        }
    }
}
