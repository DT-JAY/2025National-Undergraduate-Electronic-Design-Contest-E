#ifndef __USART_0_H__
#define __USART_0_H__

#include <stdio.h>
#include <string.h>

int fputc(int c, FILE* stream);
int fputs(const char* restrict s,FILE* restrict stream);
int puts(const char* _ptr);

#endif
