#include "ti_msp_dl_config.h"
#include "math.h"
#include "Base_Move.h"

/*由曲率计算最大速度，
  数据来自Base_Data结构体,结果储存至Base_Data*/
void Base_Culculate_Speed_At_Curvature(Base_Struct* pBase_Data)
{
    float x = pBase_Data->Target_Curvature;
    pBase_Data->Target_Linear_Speed = 0.25/(1+0.2*pow(x,4))+0.25;
}

/*设置小车运动状态，由目标线速度和曲率计算电机转速、舵机角度
  数据来自Base_Data结构体，结果储存至Base_Data，
  PID服务函数将自动执行该结构体储存的数据*/
void Set_Move_Profile(Base_Struct* pBase_Data)
{
    /*曲率为0的情况*/
    if(pBase_Data->Target_Curvature == 0)
    {
        /*简单将速度赋值*/
        pBase_Data->Target_Speed_Left = pBase_Data->Target_Linear_Speed;
        pBase_Data->Target_Speed_Right = pBase_Data->Target_Linear_Speed;

        /*舵机角度设为0*/
        pBase_Data->Base_Servo_Angle_Deg = 0;
    }


    /*曲率不为0的情况：曲率>0为右转，曲率<0为左转*/
    else if(pBase_Data->Target_Curvature != 0)
    {
        /*计算左侧轮子速度*/
        pBase_Data->Target_Speed_Left = pBase_Data->Target_Linear_Speed * abs_float(pBase_Data->Target_Curvature) * 
        abs_float((1.0/pBase_Data->Target_Curvature) + (L1/2.0));

        /*计算右侧轮子速度*/
        pBase_Data->Target_Speed_Right = pBase_Data->Target_Linear_Speed * abs_float(pBase_Data->Target_Curvature) * 
        abs_float((1.0/pBase_Data->Target_Curvature) - (L1/2.0));

        /*曲率限幅（仅计算舵机转角时计算*/
        if(pBase_Data->Target_Curvature > Max_Curvature) pBase_Data->Target_Curvature = Max_Curvature;
        else if(pBase_Data->Target_Curvature < -Max_Curvature) pBase_Data->Target_Curvature = -Max_Curvature;

        /*中间变量Alpha，用于关联舵机角度和右前轮转角*/
        float Alpha = (float)atan( (double)L3/ ( 1.0/pBase_Data->Target_Curvature + L1/2.0 ) );

        /*计算舵机角度*/
        float x = pBase_Data->Target_Curvature;
        pBase_Data->Base_Servo_Angle_Deg = 0.07 -12.6*x -0.34*pow(x,2) -0.0582*pow(x,3) - 0.031*pow(x,4);
    }
}

/*设置舵机角度*/
void Set_Base_Servo_Angle(float Angle_Deg)
{
    if(Angle_Deg > 90)
    {
        Angle_Deg = 90;
    }
    else if(Angle_Deg < -90)
    {
        Angle_Deg = -90;
    }
    uint16_t CompareValue = (1000*Angle_Deg)/180+750;
    DL_TimerG_setCaptureCompareValue(Base_Servo_INST, CompareValue, DL_TIMER_CC_0_INDEX);
}

/*取绝对值函数*/
float abs_float(float Source)
{
    if(Source >= 0)
    {
        return Source;
    }
    else
    {
        return -Source;
    }
}

/*转换单位函数*/
float Turn_Deg(double Rad)
{
    return 180*Rad/Pi;
}

/*转换单位函数*/
float Turn_Rad(double Deg)
{
    return Pi*Deg/180;
}
