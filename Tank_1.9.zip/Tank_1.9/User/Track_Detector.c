#include "ti_msp_dl_config.h"
#include "Track_Detector.h"

static int8_t TD_Data_Array[8];

/*循迹检测服务函数*/
void Track_Detector_Detect_Handler(Track_Detector_Struct* pTD_Data)
{
    //检测轨迹
    Get_Track_Detector_Data(pTD_Data,TD_Data_Array);

    //依据轨迹检测的数据，决定工作模式
    if((pTD_Data->Raw | 0x81) != 0xFF)
    {
        if(pTD_Data->Dispersion >= 8) //如果离散度>=8，表明前进方向与线条方向夹角延申方向差距过大
        {
            pTD_Data->Result = Deviating_State;
        }
        else if(pTD_Data->Dispersion < 8) //如果离散度<8，表明前进方向与线条方向夹角延申方向相近
        {
            pTD_Data->Result = Following_State;
        }
    }
    else //如果没有检测到黑线
    {
        pTD_Data->Result = Missing_State;
    }
}

/*获取循迹模块数据，存入TD_Data结构体*/
void Get_Track_Detector_Data(Track_Detector_Struct* pTD_Data,int8_t* TD_Data_Array)
{
    /*储存上一个结果*/
    pTD_Data->Last_Result = pTD_Data->Result;

    /*读取原始数据*/
    pTD_Data->Raw = Read_NO_MCU_TD_Raw(pTD_Data->Raw);

    /*将数据处理成数组，每一字节代表一个探头，具体数值表示其位置，用于计算偏移量和离散程度*/
    TD_Data_Process(TD_Data_Array,pTD_Data->Raw);

    /*计算偏移程度*/
    pTD_Data->Offset = Get_TD_Offet_Data(TD_Data_Array);

    /*计算离散程度*/
    pTD_Data->Dispersion = Get_TD_Dispersion_Data(TD_Data_Array , pTD_Data->Offset);
}

/*获取离散程度，数据来源为int8_t TD_Data_Array[8]*/
float Get_TD_Dispersion_Data(int8_t* TD_Data_Array , float TD_Offet)
{
    float TD_Dispersion=0;
    int8_t Count=0;
    for(uint8_t i=0 ; i<8 ; i++)
    {
        /*累加TD_Data_Array[]的绝对值，其平均值可以描述离散程度*/
        if(TD_Data_Array[i] != 0)
        {
            TD_Dispersion += pow((TD_Data_Array[i] - TD_Offet),2);
            Count++; //记录识别到黑线的探头的数量
        }
    }
    TD_Dispersion /= (float)Count;
    return TD_Dispersion;
}

/*获取偏移程度，数据来源为uint8_t TD_Data_Array[8]*/
float Get_TD_Offet_Data(int8_t* TD_Data_Array)
{
    float TD_Offet=0;
    int8_t Count=0;
    for(uint8_t i=0 ; i<8 ; i++)
    {
        if(TD_Data_Array[i] != 0)
        {
            TD_Offet += TD_Data_Array[i]; //累加TD_Data_Array[]，其平均值可以描述偏移程度
            Count++; //记录识别到黑线的探头的数量
        }
    }
    TD_Offet /= (float)Count;
    return TD_Offet;
}

/*处理循迹模块数据*/
void TD_Data_Process(int8_t* TD_Data_Array,uint8_t TD_Data_Raw)
{
    for(uint8_t i=0 ; i<8 ; i++)
    {
        /*确认黑线位置，低位为左侧，高位为右侧，如果为白色则为0，如果为黑色则为非0*/
        if((TD_Data_Raw & (0x01<<i)) == 0)
        {
            TD_Data_Array[i] = 1;
        }
        else
        {
            TD_Data_Array[i] = 0;
        }

        /*用符号区分左右侧：左侧为-，右侧为+*/
        if(i<4)
        {
            TD_Data_Array[i] = -TD_Data_Array[i];
        }

        /*用绝对值大小描述偏移量*/
        if(i==0 || i==7)
        {
            TD_Data_Array[i] *= 0;  //容易受到轮子影响，舍弃
        }
        else if(i==1 || i==6)
        {
            TD_Data_Array[i] *= 5;
        }
        else if(i==2 || i==5)
        {
            TD_Data_Array[i] *= 3;
        }
    }
}

/*获取检测到的循迹模块的数据
  uint8_t Detector_Reslut的最高位为右侧，最位为左侧
  黑色为低电平，白色为高电平*/
uint8_t Read_Track_Detector_Raw(void)
{
    uint8_t Detector_Reslut=0;
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_1_PORT,GPIO_Track_Detector_Detector_1_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<0);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_2_PORT,GPIO_Track_Detector_Detector_2_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<1);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_3_PORT,GPIO_Track_Detector_Detector_3_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<2);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_4_PORT,GPIO_Track_Detector_Detector_4_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<3);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_5_PORT,GPIO_Track_Detector_Detector_5_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<4);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_6_PORT,GPIO_Track_Detector_Detector_6_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<5);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_7_PORT,GPIO_Track_Detector_Detector_7_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<6);
    }
    if(DL_GPIO_readPins(GPIO_Track_Detector_Detector_8_PORT,GPIO_Track_Detector_Detector_8_PIN) != 0)
    {
        Detector_Reslut |= (0x01<<7);
    }
    return Detector_Reslut;
}
