#include "ti_msp_dl_config.h"
#include "GS_ADC.h"

volatile uint8_t ADC_Flag = 0;

unsigned int adc_getValue(void)
{
    unsigned int gAdcResult = 0;

    ADC_Flag = 0;
    // DL_ADC12_enableInterrupt(ADC12_0_INST,DL_ADC12_IIDX_MEM0_RESULT_LOADED);
    //使能ADC转换
    DL_ADC12_enableConversions(ADC12_0_INST);
    //软件触发ADC开始转换
    DL_ADC12_startConversion(ADC12_0_INST);

    //如果当前状态 不是 空闲状态
    // Delay_us(125);
    while (DL_ADC12_getStatus(ADC12_0_INST) != DL_ADC12_STATUS_CONVERSION_IDLE);
    // while (ADC_Flag == 0);

    //清除触发转换状态
    DL_ADC12_stopConversion(ADC12_0_INST);
    //失能ADC转换
    DL_ADC12_disableConversions(ADC12_0_INST);

    //获取数据
    gAdcResult = DL_ADC12_getMemResult(ADC12_0_INST, ADC12_0_ADCMEM_0);

    return gAdcResult;
}

// void ADC12_0_INST_IRQHandler(void)
// {
//     switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST))
//     {
//         case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
//             ADC_Flag = 1;
//             break;
//         default:
//             ADC_Flag = 1;
//             break;
//     }
// }
