#include "ti_msp_dl_config.h"
#include "PID.h"
#include "Usart_0.h"

/*=======================================================================================================================================*/

/*云台PID变量及参数*/
static PID_Input_Struct PT_Omega_Theta_PID_Input={0}; //储存误差积分、上次误差、上次输出
static PID_Param_Struct PT_Omega_Theta_PID_Param={0.0025,0.001,0.001,100.0,0.0}; //PID参数
#define Max_Omega 45
static PID_Input_Struct PT_Angle_Phi_PID_Input={0}; //储存误差积分、上次误差、上次输出
static PID_Param_Struct PT_Angle_Phi_PID_Param={0.0005,0.001,0.0001,100.0,0.0}; //PID参数
#define Max_Angle 15
#define Min_Angle -15
static PID_Input_Struct PT_Theta_Compensation_PID_Input={0}; //储存误差积分、上次误差、上次输出
static PID_Param_Struct PT_Theta_Compensation_PID_Param={0.06,0.01,0.001,5.0,0.0}; //PID参数

/*云台PID中断服务函数*/
void Pan_Tilt_PID_Handler(Pan_Tilt_Struct* pPT_Data,Base_Struct* pBase_Data)
{
    //依据横向偏移计算Theta角的角速度
    PT_Omega_Theta_PID_Input.Actual = pPT_Data->Actual_Theta_Offset;
    PT_Omega_Theta_PID_Input.Target = pPT_Data->Target_Theta_Offset;
    pPT_Data->Target_Omega_Theta = -90*PID_Calculate(&PT_Omega_Theta_PID_Input,&PT_Omega_Theta_PID_Param);

    //依据纵向偏移计算Phi角的角度
    PT_Angle_Phi_PID_Input.Actual = pPT_Data->Actual_Phi_Offset;
    PT_Angle_Phi_PID_Input.Target = pPT_Data->Target_Phi_Offset;
    pPT_Data->Target_Angle_Phi = -90*PID_Calculate(&PT_Angle_Phi_PID_Input,&PT_Angle_Phi_PID_Param);

    /*底盘角速度补偿量*/
    //计算底盘角速度
    float Base_Omega_Deg = -Turn_Deg((double)pBase_Data->Actual_Curvature * (double)pBase_Data->Actual_Linear_Speed);
    //小车会给云台底座带来大小为Base_Omega的角速度
    PT_Theta_Compensation_PID_Input.Actual = Base_Omega_Deg;
    //目标为让云台静止，不受底盘角速度影响
    PT_Theta_Compensation_PID_Input.Target = 0;
    float Omega_Theta_Compensation = PID_Calculate(&PT_Theta_Compensation_PID_Input,&PT_Theta_Compensation_PID_Param);
    //底座Theta角速度加上上一步算出的补偿量
    pPT_Data->Target_Omega_Theta += Omega_Theta_Compensation;

    //Theta角速度限幅
    if(pPT_Data->Target_Omega_Theta > Max_Omega) pPT_Data->Target_Omega_Theta = Max_Omega;
    else if(pPT_Data->Target_Omega_Theta < -Max_Omega) pPT_Data->Target_Omega_Theta = -Max_Omega;
    //Phi角限幅
    if(pPT_Data->Target_Angle_Phi > Max_Angle) pPT_Data->Target_Angle_Phi = Max_Angle;
    else if(pPT_Data->Target_Angle_Phi < Min_Angle) pPT_Data->Target_Angle_Phi = Min_Angle;

    Set_Pan_Tilt_Profile(pPT_Data->Target_Omega_Theta,pPT_Data->Target_Angle_Phi);
}

/*=======================================================================================================================================*/

/*底盘电机PID变量及参数*/
static PID_Input_Struct Base_Wheel_Left_PID_Input={0};
static PID_Input_Struct Base_Wheel_Right_PID_Input={0};
PID_Param_Struct Base_Wheel_Speed_PID_Param={0.2,0.2,0.001,5.0,0.0};

/*底盘电机PID服务函数*/
void Base_Motor_PID_Handler(Base_Struct* pBase_Data)
{
    //PID计算电机的占空比
    Base_Wheel_Left_PID_Input.Actual = pBase_Data->Actual_Speed_Left;
    Base_Wheel_Left_PID_Input.Target = pBase_Data->Target_Speed_Left;
    pBase_Data->Target_Power_Left = PID_Calculate(&Base_Wheel_Left_PID_Input,&Base_Wheel_Speed_PID_Param);
    Base_Wheel_Right_PID_Input.Actual = pBase_Data->Actual_Speed_Right;
    Base_Wheel_Right_PID_Input.Target = pBase_Data->Target_Speed_Right;
    pBase_Data->Target_Power_Right = PID_Calculate(&Base_Wheel_Right_PID_Input,&Base_Wheel_Speed_PID_Param);

    //设置占空比
    Set_Motor_Power(pBase_Data);
}

/*设置误差积分，防止开启电机供电时由于积分项过大*/
void Set_Base_Motor_PID_Error_Int(float Reference)
{
    Base_Wheel_Left_PID_Input.Error_Int = Reference;
    Base_Wheel_Right_PID_Input.Error_Int = Reference;
}

/*=======================================================================================================================================*/

/*小车循迹PID变量及参数*/
PID_Input_Struct Base_Follow_Track_PID_Input={0};
PID_Param_Struct Base_Follow_Track_PID_Param={0.060,0.0,0.0,2.0,0.0};
/*曲率比例系数*/
#define Curvature_Param 6

/*小车循迹PID服务函数*/
void Base_Follow_Track_PID_Handler(Base_Struct* pBase_Data,Track_Detector_Struct* pTD_Data)
{
    float Offset = pTD_Data->Offset;//(float)pTD_Data->Offset/2.0 * 0.012; //转换单位(m)

    /*如果正在正常巡线，则以最大速度沿线行驶*/
    if(pTD_Data->Result == Following_State)
    {
        //PID控制偏移量为0
        Base_Follow_Track_PID_Input.Actual = Offset;
        Base_Follow_Track_PID_Input.Target = 2;
        pBase_Data->Target_Curvature = -Curvature_Param * 
        PID_Calculate(&Base_Follow_Track_PID_Input,&Base_Follow_Track_PID_Param);

        //计算该曲率下最大速度，数据来源于Base_Data，结果储存于Base_Data
        Base_Culculate_Speed_At_Curvature(pBase_Data);
    }

    /*如果遇到大角度转折，则刹车*/
    else if(pTD_Data->Result == Deviating_State)
    {
        //持续保持检测目标曲率，有助于回到正轨
        if(pTD_Data->Offset > 0)
        {
            pBase_Data->Target_Curvature = 20;
        }
        else if(pTD_Data->Offset < 0)
        {
            pBase_Data->Target_Curvature = -20;
        }
        else
        {
            pBase_Data->Target_Curvature = -20;
        }

        //减速至0.2m/s
        pBase_Data->Target_Linear_Speed = 0.2;
    }

    /*如果没有检测到黑线，则保持迷失前的转向方向，以最大曲率转向*/
    else if(pTD_Data->Result == Missing_State)
    {
        //减速至0.2m/s
        pBase_Data->Target_Linear_Speed = 0.2;

        if(pBase_Data->Target_Curvature > 0) //如果原先目标转向方向为右，则迷失后以最大曲率向右旋转
        {
            pBase_Data->Target_Curvature = 20;
        }
        else if(pBase_Data->Target_Curvature < 0) //如果原先目标转向方向为左，则迷失后以最大曲率向左旋转
        {
            pBase_Data->Target_Curvature = -20;
        }
        else //罕见情况：原先目标方向为直行，则向左转（可调整）
        {
            pBase_Data->Target_Curvature = 20;
        }
    }

    /*错误情况，停车*/
    else
    {
        pBase_Data->Target_Linear_Speed = 0;
        pBase_Data->Target_Curvature = 0;
    }

    /*设置底盘运动状态*/
    Set_Move_Profile(pBase_Data);
}

/*=======================================================================================================================================*/

/*PID算法函数*/
float PID_Calculate(PID_Input_Struct* pInput,PID_Param_Struct* pParam)
{
    float Error = pInput->Target - pInput->Actual;
    pInput->Error_Int += Error;

    /*积分限幅*/
    if(pInput->Error_Int > pParam->Int_Limit) pInput->Error_Int = pParam->Int_Limit;
    else if(pInput->Error_Int < -pParam->Int_Limit) pInput->Error_Int = -pParam->Int_Limit;

    /*计算Output*/
    float Output = //pInput->Last_Output + 
    ( Error*pParam->Kp + pInput->Error_Int*pParam->Ki + (Error-pInput->Last_Error)*pParam->Kd );

    pInput->Last_Error = Error; //储存误差，作为下一周期的Last_Error

    /*死区：如误差在死区范围内则输出上一次的Output*/
    if(Error > -pParam->Dead_Zone && Error < pParam->Dead_Zone) Output = pInput->Last_Output;

    pInput->Last_Output = Output; //储存Output，作为下一循环的死区参考
    
    return Output;
}
