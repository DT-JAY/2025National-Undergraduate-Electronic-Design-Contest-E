#ifndef __SWITCH_H__
#define __SWITCH_H__

#include "Delay.h"
#include "PID.h"

#define Aim_At_Center 0xCE
#define Aim_At_Circle 0xC1
#define Disable_Aim 0xDA

#define Unfinished 0x00
#define Finished 0x01

typedef struct{
    uint8_t Aim_Mode;
    uint8_t Config_State;
    uint8_t Target_Rounds;
    uint8_t Target_Turns;
    uint8_t Actual_Turns;
}Task_Structure;

void Switch_Handler(Task_Structure* pTask_Data,uint8_t* Tracking_Mode);

#endif
