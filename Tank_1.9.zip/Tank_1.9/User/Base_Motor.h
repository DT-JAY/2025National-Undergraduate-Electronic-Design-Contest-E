#ifndef __BASE_MOTOR_H__
#define __BASE_MOTOR_H__

#include <stdlib.h>
#include "PID.h"
#include "Base_Move.h"

void Set_Motor_Power(Base_Struct* pBase_Data);

#endif
