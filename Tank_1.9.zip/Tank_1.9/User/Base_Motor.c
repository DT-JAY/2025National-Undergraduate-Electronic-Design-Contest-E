#include "ti_msp_dl_config.h"
#include "Base_Motor.h"

/*设置电机占空比（数据来自结构体Base_Data中储存的Target_Power）*/
void Set_Motor_Power(Base_Struct* pBase_Data)
{
    /*占空比限幅，防止超出100%*/
    if(pBase_Data->Target_Power_Left > 1.0)
    {
        pBase_Data->Target_Power_Left = 1.0;
    }
    else if (pBase_Data->Target_Power_Left < -1.0)
    {
        pBase_Data->Target_Power_Left = -1.0;
    }

    uint16_t CompareValue;

    if (pBase_Data->Target_Power_Left >= 0)    //依据输入值的符号判断电机旋转方向
    {
        CompareValue = (uint16_t)(pBase_Data->Target_Power_Left*10000);    //计算比较寄存器的值
        DL_GPIO_setPins(GPIO_Motor_AIN1_PORT,GPIO_Motor_AIN1_PIN);
        DL_GPIO_clearPins(GPIO_Motor_AIN2_PORT,GPIO_Motor_AIN2_PIN);
    }
    else if (pBase_Data->Target_Power_Left < 0)
    {
        CompareValue = (uint16_t)(-pBase_Data->Target_Power_Left*10000);    //计算比较寄存器的值
        DL_GPIO_clearPins(GPIO_Motor_AIN1_PORT,GPIO_Motor_AIN1_PIN);
        DL_GPIO_setPins(GPIO_Motor_AIN2_PORT,GPIO_Motor_AIN2_PIN);
    }
    DL_TimerG_setCaptureCompareValue(Base_Motor_INST,CompareValue,GPIO_Base_Motor_C0_IDX);


    if (pBase_Data->Target_Power_Right >= 0)    //依据输入值的符号判断电机旋转方向
    {
        CompareValue = (uint16_t)(pBase_Data->Target_Power_Right*10000);    //计算比较寄存器的值
        DL_GPIO_setPins(GPIO_Motor_BIN1_PORT,GPIO_Motor_BIN1_PIN);
        DL_GPIO_clearPins(GPIO_Motor_BIN2_PORT,GPIO_Motor_BIN2_PIN);
    }
    else if (pBase_Data->Target_Power_Right < 0)
    {
        CompareValue = (uint16_t)(-pBase_Data->Target_Power_Right*10000);    //计算比较寄存器的值
        DL_GPIO_clearPins(GPIO_Motor_BIN1_PORT,GPIO_Motor_BIN1_PIN);
        DL_GPIO_setPins(GPIO_Motor_BIN2_PORT,GPIO_Motor_BIN2_PIN);
    }
    DL_TimerG_setCaptureCompareValue(Base_Motor_INST,CompareValue,GPIO_Base_Motor_C1_IDX);
}
