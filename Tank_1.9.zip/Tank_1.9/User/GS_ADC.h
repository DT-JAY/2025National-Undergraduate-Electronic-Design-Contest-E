#ifndef __GS_ADC_H__
#define __GS_ADC_H__

#include "Grayscale_Sensor.h"

unsigned int adc_getValue(void);

#endif
