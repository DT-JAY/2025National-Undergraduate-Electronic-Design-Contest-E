#ifndef __PAN_TILT_H__
#define __PAN_TILT_H__

#define Opem_MV_PT 'M'
#define Laser_PT 'L'

typedef struct{
    float Actual_Theta_Offset;
    float Actual_Phi_Offset;
    float Target_Theta_Offset;
    float Target_Phi_Offset;
    float Target_Omega_Theta;
    float Target_Angle_Phi;
}Pan_Tilt_Struct;

void Set_Pan_Tilt_Profile(float Omega_Theta_Deg,float Angle_Phi_Deg);
// void Set_Laser_PT(float Angle_Theta_Deg,float Angle_Phi_Deg);

#endif
