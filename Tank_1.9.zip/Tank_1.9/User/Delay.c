#include "ti_msp_dl_config.h"
#include "Delay.h"

void Delay_us(uint32_t Delay_Time)
{
    for (;Delay_Time>0;Delay_Time--)
    {
        delay_cycles(80);
    }
}

void Delay_ms(uint32_t Delay_Time)
{
    for (;Delay_Time>0;Delay_Time--)
    {
        delay_cycles(80000);
    }
}
