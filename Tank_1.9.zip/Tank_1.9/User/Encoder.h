#ifndef __Encoder_H__
#define __Encoder_H__

#include "Base_Move.h"

#define Line_Count 13
#define Reduct_Ratio 28
#define Wheel_Radius 32.5

typedef struct{
    float Encoder1_Count;
    float Encoder2_Count;
    float Encoder1_Raw[3];
    float Encoder2_Raw[3];
    float Distance_Left;
    float Distance_Right;
}Encoder_Struct;

void Encoder_Detect_Handler(Base_Struct* pBase_Data,Encoder_Struct* pEncoder_Data);
void Get_Wheel_Distance(Encoder_Struct* pEncoder_Data);
void Encoder_Raw_Transfer(Encoder_Struct* pEncoder_Data);
void Encoder_Raw_Transfer_Middle_Value(Encoder_Struct* pEncoder_Data);
void Encoder_IRQHandler(Encoder_Struct* pEncoder_Data);

#endif
